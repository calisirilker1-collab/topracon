/* Topracon — ürün prototipi mantığı */
/* ================= durum ================= */
var VIEWS=[["tanitim","Tanıtım"],["kayit","Kayıt"],["panel","Panel"],["tarlalar","Tarla izleme"],["aktivite","Aktivite"],["karbon","Karbon modeli"],["kredi","Kredi"],["finansman","Finansman"],["mimari","Mimari"]];

var PRACTICES=[
 {id:"nt",  n:"Doğrudan ekim (no-till)",        d:"Pulluk ve diskaro yok, tek geçişte ekim",         r:0.42, t:"SOC"},
 {id:"rt",  n:"Azaltılmış toprak işleme",       d:"Sadece yüzeysel, sınırlı sayıda geçiş",           r:0.24, t:"SOC"},
 {id:"cc",  n:"Örtü bitkisi",                   d:"Boş dönemde fiğ/yulaf karışımı",                  r:0.55, t:"SOC"},
 {id:"leg", n:"Rotasyona baklagil eklemek",     d:"Nohut/mercimek ile azot fiksasyonu",              r:0.33, t:"SOC + N₂O"},
 {id:"res", n:"Anız bırakma, yakmama",          d:"Kalıntı tarlada, balya satışı yok",               r:0.28, t:"SOC"},
 {id:"comp",n:"Kompost / ahır gübresi",         d:"Yılda 4–6 t/ha organik madde",                    r:0.46, t:"SOC"},
 {id:"nred",n:"Sentetik azotu %20 azaltmak",    d:"Toprak analizine göre bölgesel dozlama",          r:0.31, t:"N₂O"},
 {id:"fuel",n:"Geçiş sayısını azaltmak",        d:"Daha az mazot, daha az sıkışma",                  r:0.12, t:"Fosil"},
 {id:"agf", n:"Tarla kenarı ağaç şeridi",       d:"Rüzgâr perdesi ve biyokütle karbonu",             r:0.20, t:"Biyokütle"}
];
var selPrac={nt:true,cc:true,res:true,nred:true,fuel:true};

var PARCELS=[
 {id:"12-4",ad:"Çumra · Parsel 12-4",ha:84.2,crop:"Buğday – nohut",soc:57.1,d:[.18,.16,.22,.41,.68,.79,.72,.38,.19,.15,.31,.44],
  base:[.17,.15,.20,.38,.66,.77,.70,.33,.14,.11,.12,.13],commit:"Doğrudan ekim + örtü bitkisi",flag:"ok",ndviNow:.68,dsoc:.34,
  pts:"38,26 148,18 176,74 132,116 44,104"},
 {id:"12-7",ad:"Çumra · Parsel 12-7",ha:41.6,crop:"Buğday – arpa",soc:55.4,d:[.16,.14,.19,.36,.61,.71,.65,.31,.22,.28,.34,.40],
  base:[.15,.14,.18,.35,.60,.70,.64,.29,.13,.10,.11,.12],commit:"Doğrudan ekim",flag:"warn",ndviNow:.61,dsoc:.21,
  pts:"186,22 268,34 262,92 182,80"},
 {id:"3-1", ad:"Ayrancı · Parsel 3-1",ha:122.0,crop:"Buğday – nohut",soc:53.9,d:[.14,.12,.17,.33,.57,.66,.60,.26,.11,.09,.10,.12],
  base:[.14,.13,.18,.34,.58,.67,.61,.27,.12,.10,.11,.12],commit:"Doğrudan ekim + baklagil",flag:"bad",ndviNow:.57,dsoc:.05,
  pts:"52,132 168,126 196,196 108,224 40,190"},
 {id:"8-2", ad:"Ortaköy · Parsel 8-2",ha:57.5,crop:"Ayçiçeği – buğday",soc:56.2,d:[.15,.13,.18,.39,.64,.74,.69,.35,.17,.14,.26,.38],
  base:[.15,.13,.17,.36,.62,.72,.66,.30,.13,.10,.11,.12],commit:"Şeritsel ekim + anız",flag:"ok",ndviNow:.64,dsoc:.27,
  pts:"212,116 288,124 292,198 218,206"}
];
var MONTHS=["Eyl","Eki","Kas","Ara","Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu"];
var sel="12-4", layer="ndvi";

var ACTS=[
 {d:"2025-09-18",p:"12-4",t:"Örtü bitkisi ekimi",x:"Fiğ+yulaf, 45 kg/ha, doğrudan ekim",a:84.2,v:"ok"},
 {d:"2025-10-02",p:"3-1", t:"Ekim",              x:"Buğday, doğrudan ekim mibzeri, 215 kg/ha",a:122.0,v:"ok"},
 {d:"2025-11-14",p:"12-7",t:"Örtü bitkisi ekimi",x:"Beyan sonradan girildi",a:41.6,v:"warn"},
 {d:"2026-02-20",p:"12-4",t:"Gübreleme",         x:"AS %21, 110 kg/ha (geçen yıl 150)",a:84.2,v:"ok"},
 {d:"2026-03-22",p:"3-1", t:"Toprak işleme",     x:"Kayıt yok — uydu tespiti",a:122.0,v:"bad"},
 {d:"2026-04-02",p:"8-2", t:"Ekim",              x:"Ayçiçeği, şeritsel toprak işleme",a:57.5,v:"ok"},
 {d:"2026-07-08",p:"12-4",t:"Hasat",             x:"Buğday 4,1 t/ha, anız tarlada",a:84.2,v:"ok"}
];

/* ================= yardımcılar ================= */
function n0(x){return Math.round(x).toLocaleString("tr-TR");}
function n1(x){return x.toLocaleString("tr-TR",{minimumFractionDigits:1,maximumFractionDigits:1});}
function n2(x){return x.toLocaleString("tr-TR",{minimumFractionDigits:2,maximumFractionDigits:2});}
function tl(x){return n0(x)+" ₺";}
function el(i){return document.getElementById(i);}
function toast(m){var t=el("toast");t.textContent=m;t.classList.add("on");clearTimeout(t._x);t._x=setTimeout(function(){t.classList.remove("on")},2600);}

/* ================= navigasyon ================= */
(function(){
  var nav=el("tabs");
  VIEWS.forEach(function(v){
    var b=document.createElement("button");
    b.textContent=v[1];b.dataset.v=v[0];
    b.setAttribute("aria-current", v[0]==="tanitim"?"true":"false");
    b.onclick=function(){go(v[0])};
    nav.appendChild(b);
  });
  var a=document.createElement("a");
  a.href="index.html";a.textContent="Yatırımcı sunumu";a.className="cta";
  nav.appendChild(a);
})();
function go(v){
  VIEWS.forEach(function(x){el("v-"+x[0]).classList.toggle("on",x[0]===v);});
  Array.prototype.forEach.call(el("tabs").children,function(b){b.setAttribute("aria-current",b.dataset.v===v?"true":"false");});
  window.scrollTo({top:0,behavior:"instant"});
}

/* ================= hero ================= */
var RAMP=[0,.30,.38,.44,.48,.48,.48,.45,.42,.40,.38]; // t CO2e/ha/yıl
function heroTick(){
  var y=+el("yr").value, HA=305.3, cum=0;
  for(var i=1;i<=y;i++) cum+=RAMP[i]*HA;
  el("yrLab").textContent=y+".";
  var cPerHa=cum/HA/3.67;                 // t C/ha birikim
  el("hSoc").textContent=n1(56.7+cPerHa);
  el("hCum").textContent=n0(cum);
  el("hRev").textContent=n0(cum*0.68*34*48*0.8)+" ₺";
  var fill=Math.min(96, y*1.9);
  el("coreFill").setAttribute("height",fill.toFixed(1));
  el("coreFill").setAttribute("opacity",(0.25+y*0.06).toFixed(2));
}

/* ================= harita ================= */
function fillFor(p){
  if(layer==="ndvi"){var v=p.ndviNow;return v>.66?"#2f5c2b":v>.6?"#4d7d3f":v>.55?"#7d9a4a":"#b0a75c";}
  if(layer==="soc"){var d=p.dsoc;return d>.3?"#2f5c2b":d>.2?"#6b8f43":d>.1?"#b39a4a":"#a6462e";}
  return p.flag==="ok"?"#3E6B3A":p.flag==="warn"?"#D9B44A":"#A6462E";
}
function mapSvg(interactive){
  var s='<svg viewBox="0 0 330 240">';
  s+='<rect width="330" height="240" fill="#20406b"/>';
  s+='<g stroke="#2e5688" stroke-width="1">';
  for(var i=0;i<=330;i+=22)s+='<line x1="'+i+'" y1="0" x2="'+i+'" y2="240"/>';
  for(var j=0;j<=240;j+=22)s+='<line x1="0" y1="'+j+'" x2="330" y2="'+j+'"/>';
  s+='</g>';
  s+='<path d="M0 214 Q90 200 150 218 T330 208 L330 240 L0 240 Z" fill="#1a3358" opacity=".7"/>';
  PARCELS.forEach(function(p){
    s+='<polygon class="parcel'+(p.id===sel?' sel':'')+'" points="'+p.pts+'" fill="'+fillFor(p)+'"'+(interactive?' onclick="pick(\''+p.id+'\')" tabindex="0"':'')+'><title>'+p.ad+' — '+n1(p.ha)+' ha</title></polygon>';
    var xs=p.pts.split(" ").map(function(q){return +q.split(",")[0]});
    var ys=p.pts.split(" ").map(function(q){return +q.split(",")[1]});
    var cx=xs.reduce(function(a,b){return a+b})/xs.length, cy=ys.reduce(function(a,b){return a+b})/ys.length;
    s+='<text x="'+cx+'" y="'+cy+'" fill="#F1EEE3" font-size="9.5" font-family="Instrument Sans, sans-serif" text-anchor="middle" font-weight="600" pointer-events="none">'+p.id+'</text>';
    s+='<text x="'+cx+'" y="'+(cy+12)+'" fill="rgba(241,238,227,.75)" font-size="7.5" font-family="Instrument Sans, sans-serif" text-anchor="middle" pointer-events="none">'+n1(p.ha)+' ha</text>';
  });
  s+='</svg>';
  return s;
}
var LEG={
 ndvi:[["#2f5c2b","yoğun (>0,66)"],["#4d7d3f","iyi"],["#7d9a4a","orta"],["#b0a75c","zayıf (<0,55)"]],
 soc:[["#2f5c2b","+0,30 t C/ha üzeri"],["#6b8f43","+0,20–0,30"],["#b39a4a","+0,10–0,20"],["#a6462e","kayıp riski"]],
 flag:[["#3E6B3A","beyan uyumlu"],["#D9B44A","eksik beyan"],["#A6462E","çelişki"]]
};
var LNOTE={ndvi:"Bitki örtüsü yoğunluğu — Mayıs 2026 kompoziti",soc:"Baz yıla göre organik karbon değişimi — model çıktısı",flag:"Beyan ile uydu tespitinin karşılaştırması"};
function setLayer(l){
  layer=l;["ndvi","soc","flag"].forEach(function(x){el("lb-"+x).setAttribute("aria-pressed",String(x===l))});
  el("layerNote").textContent=LNOTE[l];
  drawBig();
}
function drawLegend(){
  el("legend").innerHTML=LEG[layer].map(function(c){return '<span><i style="background:'+c[0]+'"></i>'+c[1]+'</span>'}).join("");
}
function drawBig(){el("bigMap").innerHTML=mapSvg(true);drawLegend();}
function pick(id){sel=id;drawBig();drawParcelList();drawDetail();drawNdvi();}

function drawParcelList(){
  el("bigParcels").innerHTML=PARCELS.map(function(p){
    var tg=p.flag==="ok"?'<span class="tag ok">uyumlu</span>':p.flag==="warn"?'<span class="tag warn">eksik</span>':'<span class="tag bad">çelişki</span>';
    return '<div class="prow'+(p.id===sel?' sel':'')+'" onclick="pick(\''+p.id+'\')" tabindex="0" onkeydown="if(event.key===\'Enter\')pick(\''+p.id+'\')">'
      +'<div style="flex:1"><b>'+p.ad+'</b><br><small>'+n1(p.ha)+' ha · '+p.crop+'</small></div>'+tg+'</div>';
  }).join("");
}
function drawDetail(){
  var p=PARCELS.filter(function(x){return x.id===sel})[0];
  var kr=p.ha*4.65;
  el("parcelDetail").innerHTML='<h3 style="margin-bottom:10px">'+p.ad+'</h3>'
   +'<table><tbody>'
   +'<tr><td>Alan</td><td class="num">'+n1(p.ha)+' ha</td></tr>'
   +'<tr><td>Rotasyon</td><td>'+p.crop+'</td></tr>'
   +'<tr><td>Taahhüt</td><td>'+p.commit+'</td></tr>'
   +'<tr><td>SOC (0–30 cm)</td><td class="num">'+n1(p.soc)+' t C/ha</td></tr>'
   +'<tr><td>Baz yıla göre</td><td class="num" style="color:'+(p.dsoc>.1?"var(--chl)":"var(--rust)")+'">+'+n2(p.dsoc)+' t C/ha</td></tr>'
   +'<tr><td>Son NDVI</td><td class="num">'+n2(p.ndviNow)+'</td></tr>'
   +'<tr><td>2025 tahmini kredi</td><td class="num"><b>'+n0(kr*(p.flag==="bad"?0:1))+'</b>'+(p.flag==="bad"?' <span class="tag bad">askıda</span>':'')+'</td></tr>'
   +'</tbody></table>';
}
function drawNdvi(){
  var p=PARCELS.filter(function(x){return x.id===sel})[0];
  el("ndviTitle").textContent="Parsel "+p.id;
  var W=440,H=170,pl=34,pb=26;
  function px(i){return pl+i*(W-pl-8)/11;}
  function py(v){return H-pb-v*(H-pb-10);}
  var s='<svg viewBox="0 0 '+W+' '+H+'" style="width:100%;height:auto">';
  [0,.25,.5,.75,1].forEach(function(g){
    s+='<line x1="'+pl+'" y1="'+py(g)+'" x2="'+(W-8)+'" y2="'+py(g)+'" stroke="rgba(26,22,17,.12)" stroke-width="1"/>';
    s+='<text x="4" y="'+(py(g)+3.5)+'" font-size="9" fill="rgba(26,22,17,.5)" font-family="Instrument Sans, sans-serif">'+n2(g)+'</text>';
  });
  s+='<polyline fill="none" stroke="rgba(26,22,17,.32)" stroke-width="1.8" stroke-dasharray="4 3" points="'+p.base.map(function(v,i){return px(i)+","+py(v)}).join(" ")+'"/>';
  s+='<polyline fill="none" stroke="#3E6B3A" stroke-width="2.6" points="'+p.d.map(function(v,i){return px(i)+","+py(v)}).join(" ")+'"/>';
  p.d.forEach(function(v,i){s+='<circle cx="'+px(i)+'" cy="'+py(v)+'" r="2.8" fill="#3E6B3A"/>';});
  MONTHS.forEach(function(m,i){s+='<text x="'+px(i)+'" y="'+(H-8)+'" font-size="8.5" fill="rgba(26,22,17,.5)" text-anchor="middle" font-family="Instrument Sans, sans-serif">'+m+'</text>';});
  s+='</svg>';
  s+='<div class="legend"><span><i style="background:#3E6B3A"></i>bu sezon</span><span><i style="background:rgba(26,22,17,.32)"></i>baz yıl</span></div>';
  el("ndviChart").innerHTML=s;
}

/* ================= panel tablosu ================= */
function drawPanel(){
  el("panelRows").innerHTML=PARCELS.map(function(p){
    var tg=p.flag==="ok"?'<span class="tag ok">uyumlu</span>':p.flag==="warn"?'<span class="tag warn">beyan eksik</span>':'<span class="tag bad">çelişki</span>';
    return '<tr><td><b>'+p.ad+'</b></td><td class="num">'+n1(p.ha)+' ha</td><td>'+p.crop+'</td><td>'+p.commit+'</td>'
      +'<td class="num">'+n1(p.soc)+'</td><td class="num">'+n0(p.ha*4.65*(p.flag==="bad"?0:1))+'</td><td>'+tg+'</td></tr>';
  }).join("");
}

/* ================= kayıt wizard ================= */
var WZ=[["Üretici","Kimlik ve onaylar"],["Tarla","Sınır ve toprak"],["Uygulama","Baz senaryo ve taahhüt"],["Onay","Özet ve avans"]];
var wzI=0;
(function(){
  var c=el("wzSteps");
  WZ.forEach(function(w,i){
    var b=document.createElement("button");
    b.innerHTML="<b>"+w[0]+"</b>"+w[1];
    b.setAttribute("aria-current",i===0?"true":"false");
    b.onclick=function(){wzSet(i)};
    c.appendChild(b);
  });
})();
function wzSet(i){
  wzI=Math.max(0,Math.min(3,i));
  for(var k=1;k<=4;k++) el("wz"+k).classList.toggle("on",k===wzI+1);
  Array.prototype.forEach.call(el("wzSteps").children,function(b,j){b.setAttribute("aria-current",String(j===wzI))});
  el("wzPrev").disabled=wzI===0;
  el("wzNext").textContent=wzI===3?"Kaydı tamamla":"Devam";
  wzSummary();
}
function wzGo(d){ if(wzI===3&&d===1){finishReg();return;} wzSet(wzI+d); }
function wzSummary(){
  var rate=PRACTICES.reduce(function(a,p){return a+(selPrac[p.id]?p.r:0)},0);
  var net=305.3*rate*0.68;
  el("wzEst").textContent=n0(net);
  el("sumCred").textContent=n0(net)+" kredi";
  el("sumAdv").textContent=tl(net*34*48*0.8*0.4);
  var names=PRACTICES.filter(function(p){return selPrac[p.id]}).map(function(p){return p.n}).join(", ");
  el("sumPrac").textContent=names||"seçim yapılmadı";
}
function finishReg(){toast("Kayıt tamamlandı. Sınır kontrolü 2 iş günü içinde sonuçlanır.");go("panel");}

/* ================= pratik listeleri ================= */
function pracHtml(prefix){
  return PRACTICES.map(function(p){
    return '<label class="prac"><input type="checkbox" '+(selPrac[p.id]?"checked":"")+' onchange="togglePrac(\''+p.id+'\',this.checked)">'
      +'<span style="flex:1"><b>'+p.n+'</b><small>'+p.d+' · '+p.t+'</small></span>'
      +'<span class="rate">+'+n2(p.r)+' t/ha</span></label>';
  }).join("");
}
function togglePrac(id,v){
  selPrac[id]=v;
  if(v&&id==="nt")selPrac.rt=false;
  if(v&&id==="rt")selPrac.nt=false;
  renderPrac();calc();wzSummary();
}
function renderPrac(){el("pracList").innerHTML=pracHtml("c");el("wzPrac").innerHTML=pracHtml("w");}

/* ================= karbon hesabı ================= */
function calc(){
  var area=+el("cArea").value||0, price=+el("cPrice").value||0;
  var unc=(+el("cUnc").value||0)/100, buf=(+el("cBuf").value||0)/100;
  var socR=0,otherR=0;
  PRACTICES.forEach(function(p){ if(!selPrac[p.id])return; if(p.t.indexOf("SOC")===0)socR+=p.r; else otherR+=p.r; });
  var gSoc=socR*area, gOth=otherR*area, gross=gSoc+gOth;
  var cUnc=gross*unc, afterUnc=gross-cUnc, cBuf=afterUnc*buf, net=afterUnc-cBuf;
  el("rNet").textContent=n0(net);
  el("rHa").textContent=area?n2(net/area):"0";
  el("rFarmer").textContent=tl(net*price*48*0.8);
  el("rTen").textContent=n0(net*9.2);
  var max=Math.max(gross,1);
  function row(lab,val,cls){
    return '<div class="wf-row"><div><div style="margin-bottom:3px">'+lab+'</div><div class="wf-bar '+cls+'" style="width:'+Math.max(1,Math.abs(val)/max*100)+'%"></div></div>'
      +'<div class="num" style="text-align:right">'+(val<0?"−":"")+n0(Math.abs(val))+'</div></div>';
  }
  el("wf").innerHTML=
     row("Toprak karbonu birikimi",gSoc,"")
    +row("Emisyon azaltımı (N₂O, mazot, biyokütle)",gOth,"")
    +row("Model belirsizliği kesintisi (%"+(unc*100).toFixed(0)+")",-cUnc,"cut")
    +row("Tampon havuz (%"+(buf*100).toFixed(0)+")",-cBuf,"cut")
    +row("<b>Satılabilir net kredi</b>",net,"net");
}

/* ================= finansman ================= */
function fin(){
  var ha=+el("fArea").value||0, r=+el("fRate").value||0, pr=+el("fPrice").value||0,
      fx=+el("fFx").value||0, adv=(+el("fAdv").value||0)/100, disc=(+el("fDisc").value||0)/100;
  var credits=ha*r, gross=credits*pr*fx, net=gross*0.8, a=net*adv;
  el("fGross").textContent=tl(gross);
  el("fNet").textContent=tl(net);
  el("fAdvOut").textContent=tl(a);
  el("fBal").textContent=tl(net-a);
  el("fFwd").textContent=tl(net*5*(1-disc));
}

/* ================= aktivite ================= */
var EX={
 "Ekim":[["Tür / çeşit","text","Buğday – Konya 2023"],["Tohum (kg/ha)","number","215"]],
 "Örtü bitkisi ekimi":[["Karışım","text","Fiğ + yulaf"],["Tohum (kg/ha)","number","45"]],
 "Toprak işleme":[["Alet","select","Doğrudan ekim mibzeri|Şeritsel|Diskaro|Pulluk"],["Geçiş sayısı","number","1"]],
 "Gübreleme":[["Ürün","text","Amonyum sülfat %21"],["Miktar (kg/ha)","number","110"]],
 "İlaçlama":[["Ürün","text","Glifosat 480 g/l"],["Doz (l/ha)","number","2"]],
 "Hasat":[["Verim (t/ha)","number","4.1"],["Anız","select","Tarlada bırakıldı|Balyalandı|Yakıldı"]],
 "Anız yönetimi":[["Yöntem","select","Tarlada bırakıldı|Balyalandı|Yakıldı"],["Kalıntı oranı (%)","number","80"]],
 "Otlatma":[["Hayvan birimi","number","42"],["Gün","number","18"]]
};
function acFields(){
  var t=el("acT").value, f=EX[t]||[];
  [1,2].forEach(function(i){
    var box=el("acX"+i), spec=f[i-1];
    if(!spec){box.innerHTML="";return;}
    if(spec[1]==="select"){
      box.innerHTML='<label class="f">'+spec[0]+'</label><select id="acF'+i+'">'+spec[2].split("|").map(function(o){return "<option>"+o+"</option>"}).join("")+'</select>';
    } else {
      box.innerHTML='<label class="f">'+spec[0]+'</label><input type="'+spec[1]+'" id="acF'+i+'" value="'+spec[2]+'">';
    }
  });
}
function addAct(){
  var t=el("acT").value;
  var v1=el("acF1")?el("acF1").value:"", v2=el("acF2")?el("acF2").value:"";
  var det=[v1,v2].filter(Boolean).join(" · ")+(el("acN").value?" — "+el("acN").value:"");
  ACTS.push({d:el("acD").value,p:el("acP").value.split(" ")[0],t:t,x:det||"—",a:+el("acA").value||0,v:"pending"});
  el("acN").value="";
  drawActs();
  toast("Kayıt eklendi. Uydu kontrolü sonraki geçişte (2–5 gün) yapılacak.");
}
function drawActs(){
  var rows=ACTS.slice().sort(function(a,b){return a.d<b.d?1:-1});
  el("actCount").textContent=rows.length+" kayıt · sezon 2025/26";
  el("actRows").innerHTML=rows.map(function(a){
    var tg=a.v==="ok"?'<span class="tag ok">doğrulandı</span>':a.v==="warn"?'<span class="tag warn">beyan sonradan</span>':a.v==="bad"?'<span class="tag bad">çelişki</span>':'<span class="tag">bekliyor</span>';
    var d=a.d.split("-");
    return '<tr><td class="num">'+d[2]+"."+d[1]+"."+d[0].slice(2)+'</td><td>'+a.p+'</td><td><b>'+a.t+'</b></td><td class="note" style="max-width:34ch">'+a.x+'</td><td class="num">'+n1(a.a)+' ha</td><td>'+tg+'</td></tr>';
  }).join("");
}

/* ================= başlat ================= */
el("wzMap").innerHTML=mapSvg(false);
el("wzParcels").innerHTML=PARCELS.map(function(p){
  return '<div class="prow"><div style="flex:1"><b>'+p.ad+'</b><br><small>'+p.crop+'</small></div><span class="num">'+n1(p.ha)+' ha</span></div>';
}).join("");
renderPrac();
drawBig();drawParcelList();drawDetail();drawNdvi();drawPanel();
acFields();drawActs();
calc();fin();heroTick();wzSet(0);
