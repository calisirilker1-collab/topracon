/* Topracon — yatırımcı sayfası
   1) beş yıllık gelir modeli
   2) yatırımcı ilgi formu (statik barındırma için dış endpoint / mailto yedeği) */

/* ==== FORM AYARI ====================================================
   Formspree, Basin, Getform gibi bir servisten aldığınız endpoint'i
   buraya yazın. Boş bırakılırsa form e-posta taslağı açar.
   Örnek: var FORM_ENDPOINT = "https://formspree.io/f/xxxxxxx";        */
var FORM_ENDPOINT = "";
var CONTACT_MAIL  = "yatirim@topracon.com";
/* ==================================================================== */

function el(i){return document.getElementById(i);}
function n0(x){return Math.round(x).toLocaleString("tr-TR");}
function n1(x){return x.toLocaleString("tr-TR",{minimumFractionDigits:1,maximumFractionDigits:1});}
function n2(x){return x.toLocaleString("tr-TR",{minimumFractionDigits:2,maximumFractionDigits:2});}
function toast(m){
  var t=el("toast");if(!t)return;
  t.textContent=m;t.classList.add("on");
  clearTimeout(t._x);t._x=setTimeout(function(){t.classList.remove("on")},3200);
}

/* ---------------- beş yıllık model ---------------- */
var FIXED=[0.9,1.5,2.6,4.4,6.8];          // sabit gider, M €
var VERIFY=[3.2,3.2,3.1,3.0,3.0];         // doğrulama + sicil, € / kredi
var FIELD =[1.80,1.65,1.50,1.35,1.20];    // saha ekibi, € / ha
var SAMPLE=0.90, SAT=0.35;                // örnekleme ve uydu, € / ha
var ADV_FEE=0.06, ADV_RATE=0.40, FARMER=0.80, MRV_FEE=2.0;

function model(){
  var ha0=+el("mHa").value||0, g=+el("mGrow").value||1, cr=+el("mCred").value||0,
      p0=+el("mPrice").value||0, pg=(+el("mPriceG").value||0)/100, sh=(+el("mShare").value||0)/100;
  var rows=[],ha=ha0,p=p0;
  for(var y=0;y<5;y++){
    var credits=ha*cr;
    var creditValue=credits*p;                       // €
    var commission=creditValue*sh;
    var advance=creditValue*FARMER*ADV_RATE;
    var finFee=advance*ADV_FEE;
    var mrv=ha*MRV_FEE;
    var rev=commission+finFee+mrv;
    var cogs=credits*VERIFY[y]+ha*(SAMPLE+SAT+FIELD[y]);
    var gp=rev-cogs;
    var ebitda=gp-FIXED[y]*1e6;
    rows.push({y:y+1,ha:ha,credits:credits,price:p,rev:rev,cogs:cogs,gp:gp,
               gm:rev?gp/rev:0,fixed:FIXED[y]*1e6,ebitda:ebitda,adv:advance});
    ha=ha*g; p=p*(1+pg);
  }
  return rows;
}

function renderModel(){
  var r=model(),last=r[4];
  el("mRev5").textContent=n1(last.rev/1e6)+" M €";
  el("mGm5").textContent="%"+Math.round(last.gm*100);
  el("mHa5").textContent=n0(last.ha)+" ha";
  var be=r.filter(function(x){return x.ebitda>0})[0];
  el("mBe").textContent=be?be.y+". yıl":"5 yıl içinde yok";

  /* grafik */
  var max=Math.max.apply(null,r.map(function(x){return x.rev}))||1;
  el("mChart").innerHTML=r.map(function(x){
    var hr=Math.max(2,x.rev/max*150), hg=Math.max(2,Math.max(x.gp,0)/max*150);
    return '<div><div class="pair">'
      +'<span class="b" style="height:'+hr.toFixed(0)+'px" title="Gelir '+n1(x.rev/1e6)+' M \u20ac"></span>'
      +'<span class="b2" style="height:'+hg.toFixed(0)+'px" title="Br\u00fct k\u00e2r '+n1(x.gp/1e6)+' M \u20ac"></span>'
      +'</div><div class="cap">Y'+x.y+'<br>'+n1(x.rev/1e6)+'</div></div>';
  }).join("");

  /* tablo */
  function tr(lab,f,fmt){
    return '<tr><td>'+lab+'</td>'+r.map(function(x){
      return '<td style="text-align:right" class="num">'+fmt(f(x))+'</td>';
    }).join("")+'</tr>';
  }
  var m=function(v){return n1(v/1e6)+" M";};
  el("mTable").innerHTML=
    '<thead><tr><th>Kalem</th>'+r.map(function(x){return '<th style="text-align:right">Yıl '+x.y+'</th>'}).join("")+'</tr></thead><tbody>'
    +tr("Kayıtlı alan (ha)",function(x){return x.ha},n0)
    +tr("Net kredi",function(x){return x.credits},n0)
    +tr("Kredi fiyatı (€)",function(x){return x.price},n1)
    +tr("Kredi satış değeri (€)",function(x){return x.credits*x.price},m)
    +tr("Ödenen avans (€)",function(x){return x.adv},m)
    +'<tr class="total"><td>Topracon geliri (€)</td>'+r.map(function(x){return '<td style="text-align:right" class="num">'+m(x.rev)+'</td>'}).join("")+'</tr>'
    +tr("Doğrudan maliyet (€)",function(x){return -x.cogs},m)
    +tr("Brüt kâr (€)",function(x){return x.gp},m)
    +tr("Brüt marj",function(x){return x.gm*100},function(v){return "%"+Math.round(v)})
    +tr("Sabit gider (€)",function(x){return -x.fixed},m)
    +'<tr class="total"><td>FAVÖK (€)</td>'+r.map(function(x){
        return '<td class="num" style="text-align:right;color:'+(x.ebitda<0?"var(--rust)":"inherit")+'">'+m(x.ebitda)+'</td>';
      }).join("")+'</tr>'
    +'</tbody>';
}

["mHa","mGrow","mCred","mPrice","mPriceG","mShare"].forEach(function(id){
  var e=el(id); if(e) e.addEventListener("input",renderModel);
});

/* ---------------- yatırımcı formu ---------------- */
function mark(id,bad){
  var f=el(id),e=el("e-"+id);
  if(f) f.classList.toggle("err",bad);
  if(e) e.classList.toggle("on",bad);
  return !bad;
}
function collect(){
  var docs=[];
  document.querySelectorAll('input[name="belge"]:checked').forEach(function(c){docs.push(c.value)});
  return {
    ad_soyad:el("irName").value.trim(),
    kurum:el("irOrg").value.trim(),
    eposta:el("irMail").value.trim(),
    rol:el("irRole").value,
    bilet:el("irTicket").value,
    zamanlama:el("irWhen").value,
    belgeler:docs.join(", "),
    not:el("irNote").value.trim(),
    kaynak:"topracon yatırımcı sayfası",
    tarih:new Date().toISOString()
  };
}
function mailFallback(d){
  var body=
    "Ad soyad: "+d.ad_soyad+"\n"+
    "Kurum: "+d.kurum+"\n"+
    "E-posta: "+d.eposta+"\n"+
    "Rol: "+d.rol+"\n"+
    "Bilet aralığı: "+d.bilet+"\n"+
    "Zamanlama: "+d.zamanlama+"\n"+
    "İstenen belgeler: "+d.belgeler+"\n\n"+
    "Not:\n"+(d.not||"—")+"\n";
  window.location.href="mailto:"+CONTACT_MAIL
    +"?subject="+encodeURIComponent("Veri odası talebi — "+d.kurum)
    +"&body="+encodeURIComponent(body);
}
function showOk(msg){
  el("ir").style.display="none";
  el("irOkMsg").textContent=msg;
  el("irOk").classList.add("on");
}
function irReset(){
  el("ir").reset();
  el("ir").style.display="";
  el("irOk").classList.remove("on");
  ["irName","irOrg","irMail"].forEach(function(i){mark(i,false)});
}
var form=el("ir");
if(form){
  form.addEventListener("submit",function(ev){
    ev.preventDefault();
    var d=collect(),ok=true;
    ok=mark("irName",!d.ad_soyad)&&ok;
    ok=mark("irOrg",!d.kurum)&&ok;
    ok=mark("irMail",!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(d.eposta))&&ok;
    if(!ok){toast("Zorunlu alanları tamamlayın.");return;}

    if(!FORM_ENDPOINT){
      mailFallback(d);
      showOk("Form henüz bir gönderim servisine bağlı değil, bu yüzden e-posta taslağınız açıldı. Bağlamak için README dosyasındaki adımları izleyin.");
      return;
    }
    var btn=form.querySelector('button[type="submit"]');
    btn.disabled=true;btn.textContent="Gönderiliyor…";
    fetch(FORM_ENDPOINT,{
      method:"POST",
      headers:{"Content-Type":"application/json",Accept:"application/json"},
      body:JSON.stringify(d)
    }).then(function(res){
      if(!res.ok) throw new Error(res.status);
      showOk("Veri odası erişimi "+d.eposta+" adresine 2 iş günü içinde gönderilecek.");
    }).catch(function(){
      btn.disabled=false;btn.textContent="Talebi gönder";
      toast("Gönderim başarısız. E-posta taslağı açılıyor.");
      mailFallback(d);
    });
  });
}

renderModel();
