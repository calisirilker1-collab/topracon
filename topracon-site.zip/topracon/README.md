# Topracon

Onarıcı tarım geçiş ve toprak karbonu platformu — yatırımcı sunumu ve çalışan ürün prototipi.
Tamamen statik: derleme adımı, paket kurulumu ve sunucu gerekmiyor.

**`index.html` ve `urun.html` kendi kendine yeterlidir.** Stil, mantık ve
görseller dosyanın içine gömülüdür; tek başına kopyaladığınızda da tam
çalışır. Tek harici bağımlılık Google Fonts'tan gelen iki yazı tipidir;
internet olmadığında sistem yazı tipiyle yine düzgün görünür.

| Dosya | Ne var | Gerekli mi |
|---|---|---|
| `index.html` | Yatırımcı sunumu: sorun, çözüm, kesit illüstrasyonu, pazar, iş modeli, etkileşimli 5 yıllık finansal model, rekabet, risk, tur, veri odası formu | **evet** |
| `ciftci.html` | Çiftçiye yönelik sayfa: dönüm bazlı kazanç hesabı, ne yapması gerektiği, para takvimi, dürüst şartlar bölümü, SSS ve kayıt formu | **evet** |
| `urun.html` | MVP ürün prototipi: çiftçi kaydı, tarla defteri, uydu doğrulaması, karbon modeli, kredi sicili, finansman motoru, mimari | **evet** |
| `.nojekyll` | GitHub Pages'in dosyaları Jekyll ile işlemesini engeller | evet |
| `README.md` | Bu dosya | hayır |
| `assets/` | Aynı CSS ve JS'in ayrı dosya hâli — düzenlemeyi kolaylaştırmak için duruyor. Sayfalar bu klasör olmadan da çalışır. | hayır |

## Yerelde açmak

`index.html` dosyasına çift tıklamak yeterli. Başka hiçbir dosyaya ihtiyaç yok.

> **Daha önce sayfa çıplak HTML olarak açıldıysa** sebebi `assets/` klasörünün
> kopyalanmamış olmasıydı. Artık gerek yok: stil ve mantık HTML'in içinde.
> Kaydederken tarayıcının "Web sayfası, tamamı" seçeneğini değil,
> **"Web sayfası, yalnızca HTML"** ya da doğrudan dosya kopyalamayı kullanın.

## GitHub Pages ile yayınlamak

```bash
git init
git add .
git commit -m "Topracon: yatırımcı sunumu ve MVP prototipi"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADI/topracon.git
git push -u origin main
```

Sonra depo sayfasında **Settings → Pages** bölümünde:

- **Source:** `Deploy from a branch`
- **Branch:** `main`, klasör `/ (root)`
- Kaydettikten sonra 1–2 dakika içinde site şu adreste açılır:
  `https://KULLANICI_ADI.github.io/topracon/`

Kendi alan adınızı bağlamak isterseniz aynı Pages ekranındaki **Custom domain**
alanına yazın ve alan adı sağlayıcınızda `CNAME` kaydını
`KULLANICI_ADI.github.io` adresine yönlendirin.

Cloudflare Pages, Netlify veya Vercel de aynı şekilde çalışır: depoyu bağlayın,
build komutunu boş bırakın, yayın klasörünü kök dizin olarak seçin.

## Üç sayfa, üç izleyici

- `index.html` → yatırımcı. Hektar, kredi, marj, FAVÖK dili.
- `ciftci.html` → üretici. Dönüm, ₺, mazot, mibzer dili. Karbon jargonu yok.
- `urun.html` → ürün gösterimi. Yatırımcı görüşmesinde ekran paylaşımı için.

Çiftçi sayfasındaki tüm rakamlar yatırımcı sayfasıyla aynı modelden gelir:
607 ₺/dönüm = 6.070 ₺/hektar. Birini değiştirirseniz diğerini de değiştirin.

## Formları çalıştırmak

Statik sitede form gönderimi için bir dış servis gerekir. Bağlanmadığı sürece
form, doldurulmuş bir e-posta taslağı açar — yani hiçbir talep kaybolmaz.

Bağlamak için:

1. [Formspree](https://formspree.io), [Basin](https://usebasin.com) veya
   [Getform](https://getform.io) üzerinde ücretsiz bir form oluşturun.
2. Verilen endpoint adresini kopyalayın.
3. `index.html` **ve** `ciftci.html` dosyalarını bir metin düzenleyiciyle
   açın, her birinde `FORM_ENDPOINT` satırını bulun (dosyanın sonundaki
   `<script>` bloğunun başında) ve iki satırı düzenleyin. İki sayfaya ayrı
   endpoint vermek daha iyi: yatırımcı talepleri ve çiftçi kayıtları
   karışmaz.

```js
var FORM_ENDPOINT = "https://formspree.io/f/SIZIN_ID";
var CONTACT_MAIL  = "yatirim@sizinalanadiniz.com";
```

Form JSON gönderir; alanlar `ad_soyad`, `kurum`, `eposta`, `rol`, `bilet`,
`zamanlama`, `belgeler`, `not`, `kaynak`, `tarih`.

## Sayfaya kendi rakamlarınızı koymak

Her şey ilgili HTML dosyasının içindeki `<script>` bloğunda:

- **Çiftçi kazanç rakamları:** `ciftci.html` içinde `PER_YEAR` (dönüm başına
  yıllık ödeme), `ADV` (avans oranı), `SAVE` (mazot + gübre tasarrufu).
  Hesap tablosundaki kalemler aynı dosyada düz metin.
- **Sekestrasyon oranları ve uygulama listesi:** `urun.html` içinde `PRACTICES`
- **Pilot parseller, NDVI serileri, aktivite kayıtları:** `urun.html` içinde `PARCELS`, `ACTS`
- **Beş yıllık modelin maliyet varsayımları:** `index.html` içinde
  `FIXED`, `VERIFY`, `FIELD`, `SAMPLE`, `SAT`, `ADV_FEE`, `MRV_FEE`
- **Renk paleti:** her iki dosyanın `<style>` bloğundaki `:root` değişkenleri
- **Pazar tablosu, fon kullanımı, kilometre taşları:** `index.html` içinde doğrudan metin

## Uyarı

Sitedeki tüm pazar büyüklükleri, sekestrasyon oranları, kredi fiyatları ve
finansal projeksiyonlar model varsayımıdır; bağımsız olarak doğrulanmamıştır.
Gerçek bir yatırım görüşmesinden önce TÜİK/ÇKS alan verilerinin, literatürdeki
sekestrasyon aralıklarının ve güncel karbon fiyatlarının kaynağıyla teyit
edilmesi gerekir. Metodoloji, doğrulayıcı ve sicil isimleri örnek amaçlıdır.
Bu site yatırım tavsiyesi değildir.
