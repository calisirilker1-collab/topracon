# Topracon

Onarıcı tarım geçiş ve toprak karbonu platformu — yatırımcı sunumu ve çalışan ürün prototipi.
Tamamen statik: derleme adımı, paket kurulumu ve sunucu gerekmiyor.

**`index.html` ve `urun.html` kendi kendine yeterlidir.** Stil, mantık ve
görseller dosyanın içine gömülüdür; tek başına kopyaladığınızda da tam
çalışır. Tek harici bağımlılık Google Fonts'tan gelen iki yazı tipidir;
internet olmadığında sistem yazı tipiyle yine düzgün görünür.

| Dosya | Ne var | Gerekli mi |
|---|---|---|
| `index.html` | Yatırımcı sunumu: sorun, çözüm, kesit illüstrasyonu, pazar, iş modeli, etkileşimli 5 yıllık finansal model, rekabet, risk, tur, veri odası formu | **evet** |
| `ciftci.html` | Çiftçiye yönelik sayfa: dönüm bazlı kazanç hesabı, ne yapması gerektiği, para takvimi, dürüst şartlar bölümü, SSS ve kayıt formu | **evet** |
| `brosur-a5.html` | 4 sayfalık A5 broşür (148 × 210 mm). İş modelini anlatır, TL rakamı vermez. Bir A4'e çift taraflı basılıp ortadan katlanır. Kayıt fişi içerir | **evet** |
| `ozet-a4.html` | Sahada elden verilecek tek sayfalık A4 özet. Yazdır/PDF butonu, siyah-beyaz fotokopi modu ve altta kesilip kooperatife teslim edilen elle doldurulan kayıt fişi | **evet** |
| `DESIGN.md` | Görsel dil: renk, tipografi, layout, bileşen, veri ve baskı kuralları. Yeni sayfa eklemeden önce okunur | hayır |
| `urun.html` | MVP ürün prototipi: çiftçi kaydı, tarla defteri, uydu doğrulaması, karbon modeli, kredi sicili, finansman motoru, mimari | **evet** |
| `.nojekyll` | GitHub Pages'in dosyaları Jekyll ile işlemesini engeller | evet |
| `README.md` | Bu dosya | hayır |
| `assets/` | Aynı CSS ve JS'in ayrı dosya hâli — düzenlemeyi kolaylaştırmak için duruyor. Sayfalar bu klasör olmadan da çalışır. | hayır |

## Yerelde açmak

`index.html` dosyasına çift tıklamak yeterli. Başka hiçbir dosyaya ihtiyaç yok.

> **Daha önce sayfa çıplak HTML olarak açıldıysa** sebebi `assets/` klasörünün
> kopyalanmamış olmasıydı. Artık gerek yok: stil ve mantık HTML'in içinde.
> Kaydederken tarayıcının "Web sayfası, tamamı" seçeneğini değil,
> **"Web sayfası, yalnızca HTML"** ya da doğrudan dosya kopyalamayı kullanın.

## GitHub Pages ile yayınlamak

```bash
git init
git add .
git commit -m "Topracon: yatırımcı sunumu ve MVP prototipi"
git branch -M main
git remote add origin https://github.com/KULLANICI_ADI/topracon.git
git push -u origin main
```

Sonra depo sayfasında **Settings → Pages** bölümünde:

- **Source:** `Deploy from a branch`
- **Branch:** `main`, klasör `/ (root)`
- Kaydettikten sonra 1–2 dakika içinde site şu adreste açılır:
  `https://KULLANICI_ADI.github.io/topracon/`

Kendi alan adınızı bağlamak isterseniz aynı Pages ekranındaki **Custom domain**
alanına yazın ve alan adı sağlayıcınızda `CNAME` kaydını
`KULLANICI_ADI.github.io` adresine yönlendirin.

Cloudflare Pages, Netlify veya Vercel de aynı şekilde çalışır: depoyu bağlayın,
build komutunu boş bırakın, yayın klasörünü kök dizin olarak seçin.

## Dört sayfa, üç izleyici

- `index.html` → yatırımcı. Hektar, kredi, marj, FAVÖK dili.
- `ciftci.html` → üretici, ekranda. Dönüm, ₺, mazot, mibzer dili. Karbon jargonu yok.
- `brosur-a5.html` → üretici, elde taşınan broşür. İş modelini anlatır, rakam vermez.
- `ozet-a4.html` → üretici, masada konuşulan tek sayfa. Dönüm başına örnek hesap içerir.
- `urun.html` → ürün gösterimi. Yatırımcı görüşmesinde ekran paylaşımı için.

Görsel dil `DESIGN.md` dosyasında tanımlı: Deep Soil `#26342B`, Field Green
`#607A55`, Clay `#A66F4F`, Wheat `#D8C69A`, Warm Soil White `#F4F1E8`,
Signal Yellow `#D6A928`. Yazı tipleri Manrope (metin) ve IBM Plex Mono
(yalnızca ölçüm, parsel kodu, tarih, rakam).

Çiftçi sayfasındaki tüm rakamlar yatırımcı sayfasıyla aynı modelden gelir:
607 ₺/dönüm = 6.070 ₺/hektar. Birini değiştirirseniz diğerini de değiştirin.

## Basılı materyal

Her iki dosyada üstte **Yazdır / PDF kaydet** ve **siyah-beyaz fotokopi modu**
düğmesi var. Hazır PDF'ler depoda:

| Dosya | Ne için |
|---|---|
| `topracon-a5-brosur.pdf` | 4 sayfa A5, renkli. Matbaaya verilecek dosya |
| `topracon-a5-brosur-A4-katlanir.pdf` | 2 yaprak A4 yatay, katlama dizgisi hazır. Çift taraflı basıp ortadan katlayın |
| `topracon-a5-brosur-siyah-beyaz.pdf` | Fotokopiyle çoğaltmak için |
| `topracon-a4-ciftci-ozeti.pdf` | Tek sayfa A4, renkli |
| `topracon-a4-ciftci-ozeti-siyah-beyaz.pdf` | Tek sayfa A4, fotokopi |

A5 broşürde **bilerek TL rakamı yoktur**: kur oynak, ayrıca aynı uygulama her
toprakta aynı sonucu vermiyor. Broşür iş modelini anlatır, tutarı ziraat
mühendisi tarlada hesaplayıp yazılı verir. A4 özette örnek hesap vardır;
onu güncellerken `ciftci.html` içindeki `PER_YEAR` değeriyle tutarlı tutun.

## Formları çalıştırmak

Statik sitede form gönderimi için bir dış servis gerekir. Bağlanmadığı sürece
form, doldurulmuş bir e-posta taslağı açar — yani hiçbir talep kaybolmaz.

Bağlamak için:

1. [Formspree](https://formspree.io), [Basin](https://usebasin.com) veya
   [Getform](https://getform.io) üzerinde ücretsiz bir form oluşturun.
2. Verilen endpoint adresini kopyalayın.
3. `index.html` **ve** `ciftci.html` dosyalarını bir metin düzenleyiciyle
   açın, her birinde `FORM_ENDPOINT` satırını bulun (dosyanın sonundaki
   `<script>` bloğunun başında) ve iki satırı düzenleyin. İki sayfaya ayrı
   endpoint vermek daha iyi: yatırımcı talepleri ve çiftçi kayıtları
   karışmaz.

```js
var FORM_ENDPOINT = "https://formspree.io/f/SIZIN_ID";
var CONTACT_MAIL  = "yatirim@sizinalanadiniz.com";
```

Form JSON gönderir; alanlar `ad_soyad`, `kurum`, `eposta`, `rol`, `bilet`,
`zamanlama`, `belgeler`, `not`, `kaynak`, `tarih`.

## Sayfaya kendi rakamlarınızı koymak

Her şey ilgili HTML dosyasının içindeki `<script>` bloğunda:

- **Çiftçi kazanç rakamları:** `ciftci.html` içinde `PER_YEAR` (dönüm başına
  yıllık ödeme), `ADV` (avans oranı), `SAVE` (mazot + gübre tasarrufu).
  Hesap tablosundaki kalemler aynı dosyada düz metin.
- **Sekestrasyon oranları ve uygulama listesi:** `urun.html` içinde `PRACTICES`
- **Pilot parseller, NDVI serileri, aktivite kayıtları:** `urun.html` içinde `PARCELS`, `ACTS`
- **Beş yıllık modelin maliyet varsayımları:** `index.html` içinde
  `FIXED`, `VERIFY`, `FIELD`, `SAMPLE`, `SAT`, `ADV_FEE`, `MRV_FEE`
- **Renk paleti:** her dosyanın `<style>` bloğundaki `:root` değişkenleri.
  Değiştirirken `DESIGN.md` dosyasını da güncelleyin.
- **A4 özetindeki telefon numarası:** `ozet-a4.html` içinde `0850 000 00 00`
  iki yerde geçer (iletişim şeridi ve alt dipnot). İkisini birlikte değiştirin.
- **Pazar tablosu, fon kullanımı, kilometre taşları:** `index.html` içinde doğrudan metin

## Uyarı

Sitedeki tüm pazar büyüklükleri, sekestrasyon oranları, kredi fiyatları ve
finansal projeksiyonlar model varsayımıdır; bağımsız olarak doğrulanmamıştır.
Gerçek bir yatırım görüşmesinden önce TÜİK/ÇKS alan verilerinin, literatürdeki
sekestrasyon aralıklarının ve güncel karbon fiyatlarının kaynağıyla teyit
edilmesi gerekir. Metodoloji, doğrulayıcı ve sicil isimleri örnek amaçlıdır.
Bu site yatırım tavsiyesi değildir.
