# TOPRACON — Design Language Brief

Bu dosya sitedeki tüm sayfaların uyduğu görsel dili tanımlar. Yeni bir sayfa
eklerken buradaki tokenları kullanın; renk veya yazı tipi uydurmayın.

---

## 01. Brand Character

Topracon nasıl hissettirmeli?

- **Agricultural, but not rustic** → Köy/organik ürün estetiği değil, modern tarım teknolojisi.
- **Scientific, but not clinical** → Fazla "laboratuvar / climate-tech startup" hissi yok.
- **Trustworthy, but not corporate** → Banka veya danışmanlık firması gibi değil.
- **Practical, not futuristic** → "Geleceğin tarımı" klişesi yerine bugün sahada işe yarayan teknoloji.
- **Grounded + intelligent** → Toprakla bağlantılı ama teknoloji tarafı güçlü.

Ana görsel fikir:

> **"Technology that comes from the soil."**
> Teknoloji yukarıdan aşağıya dayatılmıyor; topraktan ve tarladan doğuyor.

Bu fikrin sayfadaki karşılığı **toprak kesiti** motifidir: yatay katmanlar
(O / A / B / C horizonları), yukarıda açık, aşağıda koyu. Logo bu kesittir,
bölüm ayırıcı şerit bu kesittir, hero illüstrasyonu bu kesittir.

---

## 02. Color Palette

### Primary

| Ad | Hex | Kullanım |
|---|---|---|
| **Deep Soil** | `#26342B` | Başlıklar, navigation, koyu bölümler, güçlü kontrast |
| **Field Green** | `#607A55` | Ana marka rengi. Doğal ama "organik market" değil |

### Secondary

| Ad | Hex | Kullanım |
|---|---|---|
| **Clay** | `#A66F4F` | Toprak, kuru tarla, mineral hissi. Az kullanılır — grafik ve vurgu |
| **Wheat** | `#D8C69A` | Hasat, sıcaklık. Koyu zeminde metin rengi olarak da kullanılır |

### Background

| Ad | Hex | Kullanım |
|---|---|---|
| **Warm Soil White** | `#F4F1E8` | Sayfa zemini. Saf beyaz değil; baskıda çok daha karakterli |
| Warm Soil White (light) | `#FBF9F3` | Kart ve panel zemini |

### Accent

| Ad | Hex | Kullanım |
|---|---|---|
| **Signal Yellow** | `#D6A928` | Yalnızca önemli veri, uyarı ve CTA noktaları |

### Türev tonlar

| Ad | Hex | Kullanım |
|---|---|---|
| Mid Soil | `#7A4F38` | Kesitin B horizonu, orta koyu bölümler |
| Ink | `#1C2620` | Gövde metni |
| Alert | `#8E4A32` | Hata, çelişki, eksi rakamlar |

### Palette oranı

```
%60  Warm Soil White
%20  Deep Soil
%12  Field Green
%5   Clay
%3   Signal Yellow
```

Sayfayı yeşile boyamak yerine **krem + koyu yeşil ağırlıklı** tutun. Field
Green yapısal renk değil, işaret rengidir: olumlu durum, artı rakam, ana CTA.

---

## 03. Typography

Fazla "startup" görünmemesi önemli.

### Primary — Manrope

Modern, geometrik, okunaklı.

- **Heading:** Manrope Bold / ExtraBold, `letter-spacing: -.025em ~ -.04em`
- **Body:** Manrope Regular / Medium
- **Data (büyük rakam):** Manrope ExtraBold

```
TARLANIZI GÖRÜN.                                   Manrope ExtraBold
Hangi parselde ne değişiyor, tek bakışta anlayın.  Manrope Regular
```

### Secondary — IBM Plex Mono

**Yalnızca** veri, ölçüm, koordinat, tarih, hektar, parsel kodu, seri numarası,
para birimi rakamı için. Gövde metninde, başlıkta veya butonda asla.

```
PARSEL 0247
12.4 ha
NDVI 0.63
```

Bu küçük detay Topracon'a "agriculture + data" karakterini verir.

Uygulamada `--mono` şu seçicilere bağlıdır: `table .num`, `.tag`, `.legend`,
`.stack-row .val`, `.chart-bars .cap`, `.flow .when`, `.mono`.

### Ölçek

| Rol | Boyut | Ağırlık |
|---|---|---|
| Hero | `clamp(2.2rem, 6.4vw, 4rem)` | 800 |
| Bölüm başlığı | `clamp(1.7rem, 4.4vw, 2.6rem)` | 700 |
| Alt başlık | `1.28rem` | 700 |
| Gövde | `16–17.5px` | 400 |
| Not / dipnot | `.88–.9rem` | 400 |

Satır uzunluğu 60–66 karakteri geçmesin. Çiftçi sayfasında gövde bir punto
büyük (`17.5px`), çünkü sahada telefonla ve güneş altında okunuyor.

---

## 04. Layout

- Maks. genişlik **1080–1180 px**. Metin ağırlıklı bölümlerde `760–820 px`.
- Hizalama **sola**. Ortalanmış blok yok; tarım verisi tablo gibi okunur.
- Bölümler tam genişlikte yatay şeritler hâlinde yığılır — kesit mantığı.
  Koyu şerit, krem şerit, koyu şerit. Kart ızgarası içinde kart yapmayın.
- Köşe yarıçapı **3–4 px**. Yumuşak, ama "app kartı" değil.
- Gölge kullanmayın. Ayrım için `1px` çizgi (`rgba(28,38,32,.16)`) yeterli.
  Tek istisna: A4 sayfasının ekrandaki önizlemesi.
- Bölüm ayırıcı olarak **4 katmanlı kesit şeridi** (7 px yüksek) kullanılır.

---

## 05. Components

| Bileşen | Kural |
|---|---|
| **Buton** | Dolgulu dikdörtgen, `3–4px` radius, ağırlık 700. Birincil = Deep Soil ya da Field Green. CTA = Signal Yellow (koyu zeminde). Metinde ok işareti yok. |
| **KPI** | Sol kenarda `3–4px` renkli çizgi + büyük rakam + küçük etiket. Çerçeveli kart değil. Çizgi rengi anlam taşır: Field Green olumlu, Clay nötr, Alert risk. |
| **Tablo** | Dikey çizgi yok, satır altı ince çizgi var. Rakam sağa yaslı ve mono. Toplam satırı üstten `1.5px` çizgiyle ayrılır. |
| **Durum etiketi** | Küçük, `2px` radius, mono. Üç durum: uyumlu (Field Green), eksik (Signal Yellow), çelişki (Alert). |
| **Form** | Etiket üstte, kalın; alan yüksekliği çiftçi sayfasında en az `46px`. Hata mesajı alanın altında Alert renginde, tek cümle ve ne yapılacağını söyler. |
| **SSS** | Native `<details>`. JavaScript'e bağlı değil, baskıda ve JS kapalıyken de açılabilir. |

---

## 06. Data & charts

- Grafikler SVG, harici kütüphane yok.
- **NDVI rampası:** `#3E5537` → `#607A55` → `#8A9A64` → `#B7AE7B`
- **SOC değişim rampası:** `#6E8A57` → `#C0A055` → `#8E4A32` (kayıp)
- **Harita zemini:** `#2B3D42`, ızgara `#3A5158`. Uydu görüntüsü hissi için
  koyu mineral-slate; mavi kullanılmaz.
- Anlam yalnızca renkle taşınmaz — her seride etiket veya desen bulunur.
- Eksen ve veri etiketleri mono.

---

## 07. Print

A4 çıktısı markanın parçasıdır, sonradan eklenen bir dosya değil.

- Zemin **Warm Soil White**; saf beyaz bilerek kullanılmaz, kâğıtta karakteri olur.
- Ölçüler `mm`, gövde `8.6pt`, en küçük metin `6.5pt`.
- `@page { size: A4 portrait; margin: 0 }`, sayfa kendi iç boşluğunu taşır.
- **Siyah-beyaz fotokopi modu zorunlu.** Kooperatifler bu kâğıdı çoğaltır;
  dolgular kalkar, çerçeveler kalır, hiçbir bilgi yalnızca renge bağlı olmaz.
- Elle doldurulan alanlar `7mm` yüksekliğinde ve `.3mm` çizgi. Kesme çizgisi
  kesikli Clay.

---

## 08. Voice

- Her izleyiciye kendi birimiyle konuşulur: yatırımcıya **hektar / € / marj**,
  çiftçiye **dönüm / ₺ / mazot / mibzer**. Aynı sayfada ikisi karışmaz.
- Çiftçiye yönelik metinde "karbon sekestrasyonu", "MRV", "Kapsam 3" gibi
  terimler geçmez.
- Zor şartlar öne konur, dipnota saklanmaz. Tarımda güveni kuran şey budur.
- CTA ne olacağını söyler: "Kaydımı gönder" → "Kaydını aldık".
- Rakam varsa varsayımı da yazılır. Kaynağı olmayan rakam sayfaya girmez.
